<?php header( 'Status: 404 Not found' ); ?>
Not found